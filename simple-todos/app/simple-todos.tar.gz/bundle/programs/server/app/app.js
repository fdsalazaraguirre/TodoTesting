var require = meteorInstall({"imports":{"api":{"tasks.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/api/tasks.js                                                                          //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.export({
  Tasks: () => Tasks
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Tasks = new Mongo.Collection('tasks');

if (Meteor.isServer) {
  // This code only runs on the server
  // Only publish tasks that are public or belong to the current user
  Meteor.publish('tasks', function tasksPublication() {
    return Tasks.find({
      $or: [{
        private: {
          $ne: true
        }
      }, {
        owner: this.userId
      }]
    });
  });
}

Meteor.methods({
  'tasks.insert'(text) {
    check(text, String); // Make sure the user is logged in before inserting a task

    if (!Meteor.userId()) {
      throw new Meteor.Error('not-authorized');
    }

    Tasks.insert({
      text,
      createdAt: new Date(),
      owner: Meteor.userId(),
      username: Meteor.user().username
    });
  },

  'tasks.remove'(taskId) {
    check(taskId, String);
    const task = Tasks.findOne(taskId);

    if (task.private && task.owner !== Meteor.userId()) {
      // If the task is private, make sure only the owner can delete it
      throw new Meteor.Error('not-authorized');
    }

    Tasks.remove(taskId);
  },

  'tasks.setChecked'(taskId, setChecked) {
    check(taskId, String);
    check(setChecked, Boolean);
    const task = Tasks.findOne(taskId);

    if (task.private && task.owner !== Meteor.userId()) {
      // If the task is private, make sure only the owner can check it off
      throw new Meteor.Error('not-authorized');
    }

    Tasks.update(taskId, {
      $set: {
        checked: setChecked
      }
    });
  },

  'tasks.setPrivate'(taskId, setToPrivate) {
    check(taskId, String);
    check(setToPrivate, Boolean);
    const task = Tasks.findOne(taskId); // Make sure only the task owner can make a task private

    if (task.owner !== Meteor.userId()) {
      throw new Meteor.Error('not-authorized');
    }

    Tasks.update(taskId, {
      $set: {
        private: setToPrivate
      }
    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// server/main.js                                                                                //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/tasks.js"));
Meteor.startup(() => {// code to run on server at startup
});
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFza3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIlRhc2tzIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwiY2hlY2siLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwidGFza3NQdWJsaWNhdGlvbiIsImZpbmQiLCIkb3IiLCJwcml2YXRlIiwiJG5lIiwib3duZXIiLCJ1c2VySWQiLCJtZXRob2RzIiwidGV4dCIsIlN0cmluZyIsIkVycm9yIiwiaW5zZXJ0IiwiY3JlYXRlZEF0IiwiRGF0ZSIsInVzZXJuYW1lIiwidXNlciIsInRhc2tJZCIsInRhc2siLCJmaW5kT25lIiwicmVtb3ZlIiwic2V0Q2hlY2tlZCIsIkJvb2xlYW4iLCJ1cGRhdGUiLCIkc2V0IiwiY2hlY2tlZCIsInNldFRvUHJpdmF0ZSIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxTQUFNLE1BQUlBO0FBQVgsQ0FBZDtBQUFpQyxJQUFJQyxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFFBQU1ELENBQU4sRUFBUTtBQUFDQyxZQUFNRCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlFLEtBQUo7QUFBVVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUlwTCxNQUFNSixRQUFRLElBQUlLLE1BQU1FLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDs7QUFFUCxJQUFJTixPQUFPTyxRQUFYLEVBQXFCO0FBQ25CO0FBQ0E7QUFDQVAsU0FBT1EsT0FBUCxDQUFlLE9BQWYsRUFBd0IsU0FBU0MsZ0JBQVQsR0FBNEI7QUFDbEQsV0FBT1YsTUFBTVcsSUFBTixDQUFXO0FBQ2pCQyxXQUFLLENBQ0g7QUFBRUMsaUJBQVM7QUFBRUMsZUFBSztBQUFQO0FBQVgsT0FERyxFQUVIO0FBQUVDLGVBQU8sS0FBS0M7QUFBZCxPQUZHO0FBRFksS0FBWCxDQUFQO0FBTUQsR0FQRDtBQVFEOztBQUVEZixPQUFPZ0IsT0FBUCxDQUFlO0FBQ2IsaUJBQWVDLElBQWYsRUFBcUI7QUFDbkJaLFVBQU1ZLElBQU4sRUFBWUMsTUFBWixFQURtQixDQUduQjs7QUFDQSxRQUFJLENBQUVsQixPQUFPZSxNQUFQLEVBQU4sRUFBdUI7QUFDckIsWUFBTSxJQUFJZixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUVEcEIsVUFBTXFCLE1BQU4sQ0FBYTtBQUNYSCxVQURXO0FBRVhJLGlCQUFXLElBQUlDLElBQUosRUFGQTtBQUdYUixhQUFPZCxPQUFPZSxNQUFQLEVBSEk7QUFJWFEsZ0JBQVV2QixPQUFPd0IsSUFBUCxHQUFjRDtBQUpiLEtBQWI7QUFNRCxHQWZZOztBQWdCYixpQkFBZUUsTUFBZixFQUF1QjtBQUNyQnBCLFVBQU1vQixNQUFOLEVBQWNQLE1BQWQ7QUFDQSxVQUFNUSxPQUFPM0IsTUFBTTRCLE9BQU4sQ0FBY0YsTUFBZCxDQUFiOztBQUNJLFFBQUlDLEtBQUtkLE9BQUwsSUFBZ0JjLEtBQUtaLEtBQUwsS0FBZWQsT0FBT2UsTUFBUCxFQUFuQyxFQUFvRDtBQUNsRDtBQUNBLFlBQU0sSUFBSWYsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFDTHBCLFVBQU02QixNQUFOLENBQWFILE1BQWI7QUFDRCxHQXhCWTs7QUF5QmIscUJBQW1CQSxNQUFuQixFQUEyQkksVUFBM0IsRUFBdUM7QUFDckN4QixVQUFNb0IsTUFBTixFQUFjUCxNQUFkO0FBQ0FiLFVBQU13QixVQUFOLEVBQWtCQyxPQUFsQjtBQUNBLFVBQU1KLE9BQU8zQixNQUFNNEIsT0FBTixDQUFjRixNQUFkLENBQWI7O0FBQ0ksUUFBSUMsS0FBS2QsT0FBTCxJQUFnQmMsS0FBS1osS0FBTCxLQUFlZCxPQUFPZSxNQUFQLEVBQW5DLEVBQW9EO0FBQ2xEO0FBQ0EsWUFBTSxJQUFJZixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUNMcEIsVUFBTWdDLE1BQU4sQ0FBYU4sTUFBYixFQUFxQjtBQUFFTyxZQUFNO0FBQUVDLGlCQUFTSjtBQUFYO0FBQVIsS0FBckI7QUFDRCxHQWxDWTs7QUFtQ2IscUJBQW1CSixNQUFuQixFQUEyQlMsWUFBM0IsRUFBeUM7QUFDdkM3QixVQUFNb0IsTUFBTixFQUFjUCxNQUFkO0FBQ0FiLFVBQU02QixZQUFOLEVBQW9CSixPQUFwQjtBQUVBLFVBQU1KLE9BQU8zQixNQUFNNEIsT0FBTixDQUFjRixNQUFkLENBQWIsQ0FKdUMsQ0FNdkM7O0FBQ0EsUUFBSUMsS0FBS1osS0FBTCxLQUFlZCxPQUFPZSxNQUFQLEVBQW5CLEVBQW9DO0FBQ2xDLFlBQU0sSUFBSWYsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFFRHBCLFVBQU1nQyxNQUFOLENBQWFOLE1BQWIsRUFBcUI7QUFBRU8sWUFBTTtBQUFFcEIsaUJBQVNzQjtBQUFYO0FBQVIsS0FBckI7QUFDRDs7QUEvQ1ksQ0FBZixFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJbEMsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStETixPQUFPSSxLQUFQLENBQWFDLFFBQVEseUJBQVIsQ0FBYjtBQUcxRUYsT0FBT21DLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XHJcblxyXG5leHBvcnQgY29uc3QgVGFza3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndGFza3MnKTtcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuICAvLyBUaGlzIGNvZGUgb25seSBydW5zIG9uIHRoZSBzZXJ2ZXJcclxuICAvLyBPbmx5IHB1Ymxpc2ggdGFza3MgdGhhdCBhcmUgcHVibGljIG9yIGJlbG9uZyB0byB0aGUgY3VycmVudCB1c2VyXHJcbiAgTWV0ZW9yLnB1Ymxpc2goJ3Rhc2tzJywgZnVuY3Rpb24gdGFza3NQdWJsaWNhdGlvbigpIHtcclxuICAgIHJldHVybiBUYXNrcy5maW5kKHtcclxuICAgICAkb3I6IFtcclxuICAgICAgIHsgcHJpdmF0ZTogeyAkbmU6IHRydWUgfSB9LFxyXG4gICAgICAgeyBvd25lcjogdGhpcy51c2VySWQgfSxcclxuICAgICBdLFxyXG4gICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICd0YXNrcy5pbnNlcnQnKHRleHQpIHtcclxuICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XHJcblxyXG4gICAgLy8gTWFrZSBzdXJlIHRoZSB1c2VyIGlzIGxvZ2dlZCBpbiBiZWZvcmUgaW5zZXJ0aW5nIGEgdGFza1xyXG4gICAgaWYgKCEgTWV0ZW9yLnVzZXJJZCgpKSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgVGFza3MuaW5zZXJ0KHtcclxuICAgICAgdGV4dCxcclxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBvd25lcjogTWV0ZW9yLnVzZXJJZCgpLFxyXG4gICAgICB1c2VybmFtZTogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcclxuICAgIH0pO1xyXG4gIH0sXHJcbiAgJ3Rhc2tzLnJlbW92ZScodGFza0lkKSB7XHJcbiAgICBjaGVjayh0YXNrSWQsIFN0cmluZyk7XHJcbiAgICBjb25zdCB0YXNrID0gVGFza3MuZmluZE9uZSh0YXNrSWQpO1xyXG4gICAgICAgIGlmICh0YXNrLnByaXZhdGUgJiYgdGFzay5vd25lciAhPT0gTWV0ZW9yLnVzZXJJZCgpKSB7XHJcbiAgICAgICAgICAvLyBJZiB0aGUgdGFzayBpcyBwcml2YXRlLCBtYWtlIHN1cmUgb25seSB0aGUgb3duZXIgY2FuIGRlbGV0ZSBpdFxyXG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcclxuICAgICAgICB9XHJcbiAgICBUYXNrcy5yZW1vdmUodGFza0lkKTtcclxuICB9LFxyXG4gICd0YXNrcy5zZXRDaGVja2VkJyh0YXNrSWQsIHNldENoZWNrZWQpIHtcclxuICAgIGNoZWNrKHRhc2tJZCwgU3RyaW5nKTtcclxuICAgIGNoZWNrKHNldENoZWNrZWQsIEJvb2xlYW4pO1xyXG4gICAgY29uc3QgdGFzayA9IFRhc2tzLmZpbmRPbmUodGFza0lkKTtcclxuICAgICAgICBpZiAodGFzay5wcml2YXRlICYmIHRhc2sub3duZXIgIT09IE1ldGVvci51c2VySWQoKSkge1xyXG4gICAgICAgICAgLy8gSWYgdGhlIHRhc2sgaXMgcHJpdmF0ZSwgbWFrZSBzdXJlIG9ubHkgdGhlIG93bmVyIGNhbiBjaGVjayBpdCBvZmZcclxuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcbiAgICAgICAgfVxyXG4gICAgVGFza3MudXBkYXRlKHRhc2tJZCwgeyAkc2V0OiB7IGNoZWNrZWQ6IHNldENoZWNrZWQgfSB9KTtcclxuICB9LFxyXG4gICd0YXNrcy5zZXRQcml2YXRlJyh0YXNrSWQsIHNldFRvUHJpdmF0ZSkge1xyXG4gICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xyXG4gICAgY2hlY2soc2V0VG9Qcml2YXRlLCBCb29sZWFuKTtcclxuXHJcbiAgICBjb25zdCB0YXNrID0gVGFza3MuZmluZE9uZSh0YXNrSWQpO1xyXG5cclxuICAgIC8vIE1ha2Ugc3VyZSBvbmx5IHRoZSB0YXNrIG93bmVyIGNhbiBtYWtlIGEgdGFzayBwcml2YXRlXHJcbiAgICBpZiAodGFzay5vd25lciAhPT0gTWV0ZW9yLnVzZXJJZCgpKSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgVGFza3MudXBkYXRlKHRhc2tJZCwgeyAkc2V0OiB7IHByaXZhdGU6IHNldFRvUHJpdmF0ZSB9IH0pO1xyXG4gIH0sXHJcbn0pO1xyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvdGFza3MuanMnO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiJdfQ==
